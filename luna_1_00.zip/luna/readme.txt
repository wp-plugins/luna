=== Luna ===
Contributors: BirchWare
Donate link: http://birchware.se/wordpress/donate
Tags: moon phase
Requires at least: 3.3.0
Tested up to: 3.3.1
Stable tag: n/a

A plugin to show the phase of the moon in a sidebar.

== Description ==

Luna is a plugin/widget that shows the phase of the moon.

== Installation ==

1. Place the package (all files in the luna folder) in the plugins subdirectory (usually /wp-content/plugins/).
1. Choose Plugins on the Admin menu, find the Luna plugin, and Activate it.
1. Choose Widgets from the Appearance menu.
1. Find Luna amongst the Available Widgets, and move it to where you want it.
1. Done.

== Frequently Asked Questions ==

= Are there any Frequently Asked Questions? =

Not yet, no.

== Screenshots ==

screenshot.jpg

== Changelog ==

= 1.00 =
* First release.

== Upgrade Notice ==

= 1.00 =
Nothing here, move on.

